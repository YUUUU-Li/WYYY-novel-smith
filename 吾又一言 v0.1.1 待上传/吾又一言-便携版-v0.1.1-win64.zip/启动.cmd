@echo off
chcp 65001 >nul 2>nul
REM  WUYOU YIYAN - portable launcher (visible console, for troubleshooting)
REM  Double-click ??.vbs for the normal, windowless experience.
REM  THIS FILE MUST STAY PURE ASCII.
setlocal
set "PATH=%~dp0runtime;%PATH%"
cd /d "%~dp0"
if not exist "runtime\node.exe" (
  echo   [ERROR] runtime\node.exe is missing. Unzip the whole folder.
  pause
  exit /b 1
)
runtime\node.exe scripts\launch.mjs
if errorlevel 1 pause